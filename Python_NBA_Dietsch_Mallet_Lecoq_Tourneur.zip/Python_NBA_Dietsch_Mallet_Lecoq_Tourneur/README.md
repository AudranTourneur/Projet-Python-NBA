# Project NBA - Scraping & Data Analysis

### Authors
- Gabin DIETSCH 
- Judith LECOQ 
- Alexis MALLET
- Audran TOURNEUR

### Description
See analysis/Data_report.ipynb